JARVIS Android App

This is a clean starter Jarvis app:
- Voice input using Android SpeechRecognizer
- Spoken replies using Android TextToSpeech
- Minimal permissions: microphone only
- No network permission
- No camera permission
- No Bluetooth permission
- Ready for future features

GitHub:
1. Put all files/folders in the repository root.
2. Make sure .github/workflows/build-apk.yml exists.
3. Commit to main.
4. Open Actions -> Build Jarvis APK.
5. Run workflow.
6. Download the Jarvis-debug-apk artifact.

The workflow uses JDK 17 and Gradle 9.6.0 with Android Gradle Plugin 9.4.0.
