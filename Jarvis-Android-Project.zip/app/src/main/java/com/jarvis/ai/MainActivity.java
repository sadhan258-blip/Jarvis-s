package com.jarvis.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int MIC_REQUEST = 100;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech tts;
    private TextView status;
    private TextView conversation;
    private Button listenButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        buildUi();

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.getDefault());
                tts.setSpeechRate(0.95f);
            }
        });

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
        }

        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) {
                    status.setText("শুনছি...");
                }

                @Override public void onBeginningOfSpeech() {
                    status.setText("বলুন, আমি শুনছি...");
                }

                @Override public void onEndOfSpeech() {
                    status.setText("বোঝার চেষ্টা করছি...");
                }

                @Override public void onError(int error) {
                    status.setText("আবার চেষ্টা করুন");
                    listenButton.setEnabled(true);
                }

                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches =
                            results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);

                    listenButton.setEnabled(true);

                    if (matches != null && !matches.isEmpty()) {
                        String command = matches.get(0);
                        addLine("আপনি", command);
                        handleCommand(command);
                    } else {
                        say("আমি কথাটা বুঝতে পারিনি। আবার বলুন।");
                    }
                }

                @Override public void onPartialResults(Bundle partialResults) {}
                @Override public void onEvent(int eventType, Bundle params) {}
                @Override public void onBufferReceived(byte[] buffer) {}
                @Override public void onRmsChanged(float rmsdB) {}
            });
        } else {
            status.setText("এই ফোনে Speech Recognition পাওয়া যায়নি");
            listenButton.setEnabled(false);
        }
    }

    private void buildUi() {
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(36, 50, 36, 28);
        main.setBackgroundColor(Color.rgb(5, 12, 20));

        TextView title = new TextView(this);
        title.setText("J A R V I S");
        title.setTextColor(Color.rgb(0, 229, 255));
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);

        status = new TextView(this);
        status.setText("প্রস্তুত");
        status.setTextColor(Color.WHITE);
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 18, 0, 18);

        conversation = new TextView(this);
        conversation.setTextColor(Color.LTGRAY);
        conversation.setTextSize(16);
        conversation.setPadding(0, 12, 0, 12);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(conversation);
        LinearLayout.LayoutParams scrollParams =
                new LinearLayout.LayoutParams(-1, 0, 1);
        main.addView(title, new LinearLayout.LayoutParams(-1, -2));
        main.addView(status, new LinearLayout.LayoutParams(-1, -2));
        main.addView(scroll, scrollParams);

        listenButton = new Button(this);
        listenButton.setText("🎙  TALK TO JARVIS");
        listenButton.setTextSize(17);
        listenButton.setOnClickListener(v -> startListening());
        main.addView(listenButton, new LinearLayout.LayoutParams(-1, -2));

        setContentView(main);
    }

    private void startListening() {
        if (speechRecognizer == null) return;

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
            return;
        }

        listenButton.setEnabled(false);
        status.setText("শুনছি...");

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);

        speechRecognizer.startListening(intent);
    }

    private void handleCommand(String command) {
        String lower = command.toLowerCase(Locale.ROOT);

        if (lower.contains("hello") || lower.contains("হ্যালো")
                || lower.contains("হাই")) {
            say("হ্যালো। আমি জার্ভেস। কী করতে পারি?");
        } else if (lower.contains("who are you")
                || lower.contains("তুমি কে")) {
            say("আমি জার্ভেস, আপনার ফোনের ভয়েস অ্যাসিস্ট্যান্ট।");
        } else if (lower.contains("time")
                || lower.contains("সময়")) {
            String time = new java.text.SimpleDateFormat(
                    "hh:mm a", Locale.getDefault())
                    .format(new java.util.Date());
            say("এখন সময় " + time);
        } else if (lower.contains("thank")
                || lower.contains("ধন্যবাদ")) {
            say("আপনাকে স্বাগতম।");
        } else {
            say("আপনি বলেছেন: " + command);
        }
    }

    private void say(String text) {
        addLine("JARVIS", text);
        status.setText("উত্তর দিচ্ছি...");
        if (tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis");
        }
        listenButton.setEnabled(true);
    }

    private void addLine(String who, String text) {
        conversation.append(who + ": " + text + "\n\n");
    }

    @Override
    protected void onDestroy() {
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
